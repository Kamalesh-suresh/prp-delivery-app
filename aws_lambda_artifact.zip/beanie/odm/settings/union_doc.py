from beanie.odm.settings.base import ItemSettings


class UnionDocSettings(ItemSettings):
    ...
